package com.infertux.nfcexplorer;

import java.util.LinkedHashMap;
import java.util.List;

class TagTechList extends LinkedHashMap<String, List<String>> {
}
